import firebase from 'firebase';

// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyC05mzpWEcu65JQZSkcYyI_lS4MN79duCA",
    authDomain: "nam-757d7.firebaseapp.com",
    projectId: "nam-757d7",
    storageBucket: "nam-757d7.appspot.com",
    messagingSenderId: "916605006737",
    appId: "1:916605006737:web:c9f43e48f53e0c185d2030"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export default firebase;

