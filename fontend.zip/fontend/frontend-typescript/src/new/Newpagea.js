const newPagea = {
    render() {
        return /*html*/`
            <div class="container">
                <div class="text-center">
                    <h3>THẾ GIỚI GIÀY
                    Nike Air Jordan 1 – Mẫu Giày “Huyền Thoại” Ra Đời Từ “Huyền Thoại”</h3>
                    <br>
                    <div>
                        <p>Michael Jeffrey Jordan (sinh ngày 17 tháng 2 năm 1963) là một cầu thủ bóng rổ nhà nghề nổi tiếng thế 
                        giới của Hoa Kỳ đã giải nghệ. ... Sau khi thi đấu một cách nổi bật trong 
                        màu áo của đại học Bắc Carolina, Jordan tham gia vào đội Chicago Bulls của NBA năm 1984.</p>
                        <img src="https://firebasestorage.googleapis.com/v0/b/nam-757d7.appspot.com/o/off-white-air-jordan-1-lead.jpg?alt=media&token=34b7fb96-8e61-4cac-b370-346910862a58" alt="">
                    </div>
                    <br>
                    <div class="text-center">
                        <p>Được xem như một thước đo trong giới “chơi” sneaker hiện tại, Air Jordan 1 trở thành chuẩn mực và cũng là niềm mơ ước sở hữu của hầu hết các sneakerhead bởi giá trị lịch sử gắn liền với hình bóng người đàn ông với cú dunk huyền thoại – Michael Jordan.
                        </p>
                    
                    </div>
                </div>
            </div>
        `
    }
}
export default newPagea;