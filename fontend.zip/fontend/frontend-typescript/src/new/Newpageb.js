const newPageb = {
    render() {
        return /*html*/`
            <div class="container">
                <div class="text-center">
                    <h1>Thông Tin</h1>
                    <br>
                    <div>
                        <p>Michael Jeffrey Jordan (sinh ngày 17 tháng 2 năm 1963) là một cầu thủ bóng rổ nhà nghề nổi tiếng thế 
                        giới của Hoa Kỳ đã giải nghệ. ... Sau khi thi đấu một cách nổi bật trong 
                        màu áo của đại học Bắc Carolina, Jordan tham gia vào đội Chicago Bulls của NBA năm 1984.</p>
                        <img src="https://firebasestorage.googleapis.com/v0/b/nam-757d7.appspot.com/o/image%2Funnamed.jpg?alt=media&token=12371320-ce9c-4f8a-85a3-33d2f9276730" alt="">
                    </div>
                    <br>
                    <div class="text-center">
                        <p>Nếu có ai hỏi tôi thích sản phẩm của hãng nào nhất, thì tôi sẽ không ngại trả lời rằng Jordan và phải là Air 
                        Jordan Retro cơ chứ không phải những dòng performance đại trà đâu, dù rằng như thế thì tôi cũng không khác gì
                        mấy các thanh niên phong trào nửa mùa ngoài 
                        kia mỗi ngày chi hàng trăm USD mua giày để làm đầy thêm cho bộ sưu tập của mình vì nó hot.
                        </p>
                    
                    </div>
                </div>
            </div>
        `
    }
}
export default newPageb;