const newPagec = {
    render() {
        return /*html*/`
            <div class="container">
                <div class="text-center">
                    <h1>Thông Tin</h1>
                    <br>
                    <div>
                        <p>Nhưng có một điều mà ít ại biết đó là  Michael Jordan là một tín đồ 3 sọc từ thời trung học và khi vừa tốt nghiệp xong, điều MJ muốn làm nhất chính là kí hợp đồng với Adidas. Thế nhưng hãng giày nước Đức này đã không hợp tác với một chàng tân binh thấp bé nhẹ cân khi họ đã có những gã khổng lồ khác. Thế là MJ đành miễn cưỡng đặt bút kí vào “hợp đồng ma quỷ” với Nike, và mọi diễn biến câu chuyện bắt đầu từ đây.</p>
                        <img src="https://firebasestorage.googleapis.com/v0/b/nam-757d7.appspot.com/o/image%2Fmichael-jordan-jumpman-tracksuit-copy-759x500.jpg?alt=media&token=70802c7d-270c-42bb-8249-1261c3141a5a" alt="">
                    </div>
                    <br>
                    <div class="text-center">
                        <p>Air Jordan được thành lập năm 1984 như là một thương hiệu giày dép và trang thiết bị thể thao thiết kế và sản xuất riêng dành riêng cho Michael Jordan bởi một nhánh của Nike có tên thương mại là “Jordan Brand”. Các dòng giày Jordan thường được viết tắt là J’s ( viết tắt cụm từ Jordan’s) hoặc AJ ( viết tắt cụm từ Air Jordan) đi kèm số hiệu. Ví dụ: đôi Air Jordan 1 có thể viết tắt là J’s 1 hoặc AJ1.
                        </p>
                    
                    </div>
                </div>
            </div>
        `
    }
}
export default newPagec;