const Error404Page = {
    render() {
        return `
            <h1>Error404</h1>
        `
    }
}
export default Error404Page;